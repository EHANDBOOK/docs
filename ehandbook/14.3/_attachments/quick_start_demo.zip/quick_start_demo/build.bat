cls

C:\ETAS\EHANDBOOK-Container-Build_10.0.0-Windows\eHandbookCB.exe ^
-i ".\Input" ^
-o ".\Output" ^
-n "QuickStartDemo" ^
-nomatlab ^
-gensvg 

pause
